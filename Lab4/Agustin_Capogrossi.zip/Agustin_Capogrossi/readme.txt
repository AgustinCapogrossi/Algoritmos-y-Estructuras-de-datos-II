Agustín Capogrossi

Para compilar: 
gcc -Wall -Werror -Wextra -g -pedantic -std=c99 *helpers.c string.c dict.c main.c -o dict.e

Para ejecutar: ./dict.e

La mayoría de las funciones responden de manera correcta, excepto dict_remove y dict_add, la primera genera un error por violación de segmento y la segunda si bien agrega los elementos de manera correcta, al agregar un elemento ya existente lo duplica. De ser posible me gustaría conocer la forma de resolver estos problemas para que el programa sea funcional.
