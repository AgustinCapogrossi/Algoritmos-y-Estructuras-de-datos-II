Agustín Capogrossi
Para compilar utilizando el Makefile:

$ make

Para compilar sin Makefile:

$ gcc -Wall -Werror -Wextra -g -pedantic -std=c99 -o main main.c cost.c dijkstra.c graph.c set.o

El algoritmo de Dijkstra es algo confuso, si bien conseguí que diera los mismos resultados que se muestran en el video, no estoy seguro de que eso era lo que pedía el ejercicio.
