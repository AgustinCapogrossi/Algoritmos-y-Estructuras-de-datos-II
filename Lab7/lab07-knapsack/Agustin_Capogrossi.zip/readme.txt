Agustín Capogrossi

Para compilar: gcc -Wall -Werror -Wextra -g -std=c99 -o knapsack knapsack.c main.c item.c helpers.c string.c -lm

Para ejecutar todos los ejemplos: ./knapsack -bds -f input/example*.in

